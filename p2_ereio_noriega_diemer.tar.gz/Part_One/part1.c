#include <stdio.h>

int main(int argc, char argv[]) {
	
	int x = 1;
	char* phrase = "All work and no play makes Jack a dull boy\n";
	
	x = x + 1;

	printf("%d, This\n", x);

	x = x + 1;

	printf("%d, Should\n", x);

	x = x + 1;

	printf("%d, Have\n", x);

	x = x + 1;

	printf("%d, 10+\n", x);

	x = x + 1;

	printf("%d, System\n", x);

	x = x + 1;

	printf("%d, Calls\n", x);

	x = x + 1;

	printf("%d, %s\n", x, phrase);

	return 0;
} 
